import xml.dom.minidom
import sys
import getopt

if __name__ == "__main__":

    dom = xml.dom.minidom.parse('document1.xml')
    root = dom.documentElement
    myList = root.getElementsByTagName('power')
    print(myList)

    for node in myList:
        alist = node.getElementsByTagName('ID')
        print(alist)
        print(alist[0].childNodes[0].nodeValue)
        

