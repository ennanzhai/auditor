'''
This file aims to generate the concrete topology via the given cloud
configuration information

'''


